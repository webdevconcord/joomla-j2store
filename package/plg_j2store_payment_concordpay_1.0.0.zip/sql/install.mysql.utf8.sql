INSERT INTO `#__extensions` (
     `extension_id`, `package_id`, `name`, `type`, `element`,
     `changelogurl`, `folder`, `client_id`, `enabled`, `access`,
     `protected`, `locked`, `manifest_cache`, `params`, `custom_data`,
     `checked_out`, `checked_out_time`, `ordering`, `state`, `note`
     ) VALUES (
    NULL, 0, 'plg_j2store_payment_concordpay', 'plugin', 'payment_concordpay',
    NULL, 'j2store', 0, 0, 1,
    0, 0, '', '', '',
    NULL, NULL, 0, 0, NULL
);